/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [id]
    ,[category]
    ,[parent_categ]
    ,[created_at]
    ,[modified_at]
FROM [dbo].[product_category]