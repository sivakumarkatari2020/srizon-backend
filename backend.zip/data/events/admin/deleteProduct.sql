/**** Query to delete category from database ****/
DELETE FROM [dbo].[products]
WHERE [id] = @id