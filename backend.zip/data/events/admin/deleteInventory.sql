/**** Query to delete category from database ****/
DELETE FROM [dbo].[product_inventory]
WHERE [id] = @id